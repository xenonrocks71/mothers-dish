# Mother's Dish
A canteen management system
Mothers dish is a simple canteen management system.
The front-end is developed using HTML, CSS, JS and Bootstrap.
The back-end is completely developed using PHP.
We have used MySQL in this project to manage our data in a tabular format.

## Screen snapshots:
<div align="center" >
<img src ="https://github.com/Prathamesh-Patil-GitHub/mothers-dish/blob/main/output-images/mothers-dish-ouput-1.png"/>
</div>
<div align="center" >
<img src ="https://github.com/Prathamesh-Patil-GitHub/mothers-dish/blob/main/output-images/mothers-dish-ouput-2.png"/>
</div>
<div align="center" >
<img src ="https://github.com/Prathamesh-Patil-GitHub/mothers-dish/blob/main/output-images/mothers-dish-ouput-3.png"/>
</div>
